# Control Avícola

Aplicación Android para controlar ventas de huevos, créditos de tiendas, gastos, producción, mermas y reportes.

## Precios
- Persona: 30 huevos = $4.50
- Persona: 15 huevos = $2.25
- Tienda: 30 huevos = $4.25
- Crédito: disponible para tiendas

## Funciones
- Registrar ventas y pagos.
- Ver quién debe y cuánto debe.
- Aplicar abonos automáticamente a las ventas más antiguas.
- Registrar alimentos, medicinas, vitaminas, cartones, gasolina y otros gastos.
- Registrar producción y huevos perdidos/merma.
- Reportes diarios, semanales y mensuales.
- Datos guardados localmente en el teléfono.

## APK
El workflow de GitHub Actions construye automáticamente un APK de prueba cada vez que se suben cambios a `main` o `principal`.
