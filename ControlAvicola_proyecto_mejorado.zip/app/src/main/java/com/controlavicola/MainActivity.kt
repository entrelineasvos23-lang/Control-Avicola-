package com.controlavicola

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("control_avicola", MODE_PRIVATE) }
    private val green = Color.rgb(46, 125, 50)
    private val red = Color.rgb(198, 40, 40)

    private fun arr(key: String): JSONArray = try {
        JSONArray(prefs.getString(key, "[]") ?: "[]")
    } catch (_: Exception) { JSONArray() }

    private fun save(key: String, value: JSONArray) {
        prefs.edit().putString(key, value.toString()).apply()
    }

    private fun money(v: Double) = "$" + String.format(Locale.US, "%.2f", v)
    private fun date(ts: Long = System.currentTimeMillis()) =
        SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(ts))
    private fun month(ts: Long = System.currentTimeMillis()) =
        SimpleDateFormat("yyyy-MM", Locale.US).format(Date(ts))
    private fun week(ts: Long = System.currentTimeMillis()): String {
        val c = Calendar.getInstance().apply { timeInMillis = ts }
        return String.format(Locale.US, "%04d-S%02d", c.get(Calendar.YEAR), c.get(Calendar.WEEK_OF_YEAR))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        home()
    }

    private fun title(t: String): TextView = TextView(this).apply {
        text = t
        textSize = 25f
        setTextColor(green)
        setPadding(12, 18, 12, 18)
    }

    private fun button(t: String, action: () -> Unit) = Button(this).apply {
        text = t
        textSize = 17f
        setOnClickListener { action() }
        isAllCaps = false
    }

    private fun base(t: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 12)
        }
        root.addView(button("← Volver") { home() })
        root.addView(title(t))
        return root
    }

    private fun home() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 25, 22, 12)
        }
        root.addView(TextView(this).apply {
            text = "🐔 CONTROL AVÍCOLA"
            textSize = 29f
            setTextColor(green)
            gravity = Gravity.CENTER
            setPadding(5, 15, 5, 8)
        })
        root.addView(TextView(this).apply {
            text = "Control de ventas, créditos, gastos y producción"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(5, 0, 5, 20)
        })

        val s = arr("sales")
        var todaySales = 0.0
        var pending = 0.0
        for (i in 0 until s.length()) {
            val o = s.getJSONObject(i)
            if (date(o.optLong("date")) == date()) todaySales += o.optDouble("amount")
            pending += o.optDouble("pending")
        }
        root.addView(TextView(this).apply {
            text = "Ventas de hoy: ${money(todaySales)}\nPendiente de cobro: ${money(pending)}"
            textSize = 19f
            setPadding(12, 10, 12, 18)
        })

        root.addView(button("🥚 Producción y mermas") { production() })
        root.addView(button("💰 Registrar venta") { sale() })
        root.addView(button("🏪 Tiendas y créditos") { stores() })
        root.addView(button("💸 Gastos") { expenses() })
        root.addView(button("📊 Reportes") { reports() })
        root.addView(button("⚙️ Precios") { prices() })
        setContentView(root)
    }

    private fun prices() {
        val root = base("⚙️ Precios")
        root.addView(TextView(this).apply {
            text = "Persona: 30 huevos = $4.50\nPersona: 15 huevos = $2.25\nTienda: 30 huevos = $4.25\n\nLas tiendas solo pueden recibir cartones de 30 huevos."
            textSize = 19f
            setPadding(10, 10, 10, 25)
        })
        setContentView(root)
    }

    private fun sale() {
        val root = base("💰 Registrar venta")
        val customer = EditText(this).apply { hint = "Nombre del cliente o tienda" }
        val type = Spinner(this)
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("Persona", "Tienda"))
        val eggs = EditText(this).apply {
            hint = "Cantidad de huevos (15 o 30 para persona; múltiplos de 30 para tienda)"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        val status = Spinner(this)
        status.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("Pagado", "A crédito"))
        val preview = TextView(this).apply { textSize = 18f; setPadding(8, 15, 8, 15) }

        root.addView(type)
        root.addView(customer)
        root.addView(eggs)
        root.addView(status)
        root.addView(preview)
        root.addView(button("Calcular total") {
            val e = eggs.text.toString().toIntOrNull() ?: 0
            val store = type.selectedItemPosition == 1
            val valid = if (store) e > 0 && e % 30 == 0 else (e == 15 || e == 30)
            if (!valid) {
                preview.text = if (store) "Para tienda: usa múltiplos de 30 huevos." else "Para persona: usa 15 o 30 huevos."
            } else {
                val total = e / 30.0 * if (store) 4.25 else 4.50
                preview.text = "Total: ${money(total)}\nCartones equivalentes: ${e / 30.0}"
            }
        })
        root.addView(button("💾 Guardar venta") {
            val name = customer.text.toString().trim()
            val e = eggs.text.toString().toIntOrNull() ?: 0
            val store = type.selectedItemPosition == 1
            val credit = status.selectedItemPosition == 1
            val valid = name.isNotEmpty() && (if (store) e > 0 && e % 30 == 0 && credit else e == 15 || e == 30)
            if (!valid) {
                Toast.makeText(this, if (credit && !store) "El crédito está disponible para tiendas." else "Revisa los datos.", Toast.LENGTH_LONG).show()
                return@button
            }
            val total = e / 30.0 * if (store) 4.25 else 4.50
            val sales = arr("sales")
            sales.put(JSONObject()
                .put("date", System.currentTimeMillis())
                .put("customer", name)
                .put("store", store)
                .put("eggs", e)
                .put("cartons", e / 30.0)
                .put("amount", total)
                .put("paid", if (credit) 0.0 else total)
                .put("pending", if (credit) total else 0.0)
                .put("week", week())
            )
            save("sales", sales)
            Toast.makeText(this, "Venta guardada: ${money(total)}", Toast.LENGTH_LONG).show()
            home()
        })
        setContentView(root)
    }

    private fun stores() {
        val root = base("🏪 Tiendas")
        val sales = arr("sales")
        val names = LinkedHashSet<String>()
        for (i in 0 until sales.length()) if (sales.getJSONObject(i).optBoolean("store")) names.add(sales.getJSONObject(i).optString("customer"))
        if (names.isEmpty()) {
            root.addView(TextView(this).apply { text = "Todavía no hay tiendas con ventas registradas."; textSize = 18f; setPadding(10, 10, 10, 20) })
        }
        var total = 0.0
        for (name in names) {
            var debt = 0.0
            for (i in 0 until sales.length()) {
                val o = sales.getJSONObject(i)
                if (o.optBoolean("store") && o.optString("customer") == name) debt += o.optDouble("pending")
            }
            total += debt
            root.addView(button("🏪 $name\nPendiente: ${money(debt)}") { storeDetail(name) })
        }
        root.addView(TextView(this).apply {
            text = "TOTAL PENDIENTE: ${money(total)}"
            textSize = 22f
            setTextColor(red)
            setPadding(10, 20, 10, 10)
        })
        setContentView(root)
    }

    private fun storeDetail(name: String) {
        val root = base("🏪 $name")
        val sales = arr("sales")
        var debt = 0.0
        val lines = StringBuilder()
        for (i in sales.length() - 1 downTo 0) {
            val o = sales.getJSONObject(i)
            if (o.optBoolean("store") && o.optString("customer") == name) {
                debt += o.optDouble("pending")
                lines.append("${date(o.optLong("date"))} • ${o.optInt("eggs")} huevos • ${money(o.optDouble("amount"))} • pendiente ${money(o.optDouble("pending"))} • ${o.optString("week")}\n")
            }
        }
        root.addView(TextView(this).apply {
            text = "Saldo pendiente: ${money(debt)}"
            textSize = 23f
            setTextColor(if (debt > 0) red else green)
            setPadding(10, 5, 10, 15)
        })
        if (debt > 0) root.addView(button("💵 Registrar abono") { payment(name) })
        root.addView(TextView(this).apply {
            text = "Historial:\n$lines"
            textSize = 16f
            setPadding(10, 15, 10, 10)
        })
        setContentView(root)
    }

    private fun payment(name: String) {
        val e = EditText(this).apply { hint = "Monto recibido"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        AlertDialog.Builder(this).setTitle("Registrar abono")
            .setView(e)
            .setPositiveButton("Guardar") { _, _ ->
                var amount = e.text.toString().toDoubleOrNull() ?: 0.0
                if (amount <= 0) return@setPositiveButton
                val sales = arr("sales")
                for (i in 0 until sales.length()) {
                    val o = sales.getJSONObject(i)
                    val pending = o.optDouble("pending")
                    if (o.optBoolean("store") && o.optString("customer") == name && pending > 0 && amount > 0) {
                        val applied = minOf(amount, pending)
                        o.put("pending", pending - applied)
                        o.put("paid", o.optDouble("paid") + applied)
                        amount -= applied
                    }
                }
                save("sales", sales)
                storeDetail(name)
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun expenses() {
        val root = base("💸 Gastos")
        root.addView(button("➕ Registrar gasto") { newExpense() })
        val a = arr("expenses")
        var total = 0.0
        for (i in a.length() - 1 downTo 0) {
            val o = a.getJSONObject(i)
            total += o.optDouble("amount")
            root.addView(TextView(this).apply {
                text = "${date(o.optLong("date"))} • ${o.optString("category")} • ${money(o.optDouble("amount"))}\n${o.optString("note")}"
                textSize = 17f
                setPadding(10, 10, 10, 10)
            })
        }
        root.addView(TextView(this).apply { text = "Total gastos: ${money(total)}"; textSize = 21f; setPadding(10, 20, 10, 10) })
        setContentView(root)
    }

    private fun newExpense() {
        val cat = Spinner(this)
        cat.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Alimentos", "Medicinas", "Vitaminas", "Cartones", "Gasolina", "Otros"))
        val amount = EditText(this).apply { hint = "Monto en dólares"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val note = EditText(this).apply { hint = "Detalle (opcional)" }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 5, 30, 5) }
        box.addView(cat); box.addView(amount); box.addView(note)
        AlertDialog.Builder(this).setTitle("Nuevo gasto").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val n = amount.text.toString().toDoubleOrNull() ?: 0.0
                if (n > 0) {
                    val a = arr("expenses")
                    a.put(JSONObject().put("date", System.currentTimeMillis()).put("category", cat.selectedItem.toString()).put("amount", n).put("note", note.text.toString()))
                    save("expenses", a)
                    expenses()
                }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun production() {
        val root = base("🥚 Producción y mermas")
        root.addView(button("➕ Registrar producción") { newProduction() })
        val a = arr("production")
        for (i in a.length() - 1 downTo 0) {
            val o = a.getJSONObject(i)
            root.addView(TextView(this).apply {
                text = "${date(o.optLong("date"))} • Producidos: ${o.optInt("eggs")} • Perdidos/merma: ${o.optInt("loss")}"
                textSize = 17f
                setPadding(10, 10, 10, 10)
            })
        }
        setContentView(root)
    }

    private fun newProduction() {
        val eggs = EditText(this).apply { hint = "Huevos producidos"; inputType = InputType.TYPE_CLASS_NUMBER }
        val loss = EditText(this).apply { hint = "Huevos perdidos / merma"; inputType = InputType.TYPE_CLASS_NUMBER }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 5, 30, 5) }
        box.addView(eggs); box.addView(loss)
        AlertDialog.Builder(this).setTitle("Producción del día").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val p = eggs.text.toString().toIntOrNull() ?: 0
                val l = loss.text.toString().toIntOrNull() ?: 0
                if (p >= 0 && l >= 0) {
                    val a = arr("production")
                    a.put(JSONObject().put("date", System.currentTimeMillis()).put("eggs", p).put("loss", l))
                    save("production", a)
                    production()
                }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun reports() {
        val root = base("📊 Reportes")
        val sales = arr("sales")
        val expenses = arr("expenses")
        val now = System.currentTimeMillis()
        var day = 0.0; var monthSales = 0.0; var weekSales = 0.0; var pending = 0.0
        for (i in 0 until sales.length()) {
            val o = sales.getJSONObject(i)
            val ts = o.optLong("date")
            if (date(ts) == date(now)) day += o.optDouble("amount")
            if (month(ts) == month(now)) monthSales += o.optDouble("amount")
            if (week(ts) == week(now)) weekSales += o.optDouble("amount")
            pending += o.optDouble("pending")
        }
        var monthExpenses = 0.0
        for (i in 0 until expenses.length()) if (month(expenses.getJSONObject(i).optLong("date")) == month(now))
            monthExpenses += expenses.getJSONObject(i).optDouble("amount")
        root.addView(TextView(this).apply {
            text = "HOY\nVentas: ${money(day)}\n\nSEMANA ${week(now)}\nVentas: ${money(weekSales)}\n\nMES ${month(now)}\nVentas: ${money(monthSales)}\nGastos: ${money(monthExpenses)}\nResultado estimado: ${money(monthSales - monthExpenses)}\n\nPendiente total: ${money(pending)}"
            textSize = 19f
            setPadding(10, 10, 10, 10)
        })
        setContentView(root)
    }
}
